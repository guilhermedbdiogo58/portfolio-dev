import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Figura {
    private List<Object> primitivas;

    public Figura() {
        primitivas = new ArrayList<>();
    }

    public void adicionar(Object obj) {
        primitivas.add(obj);
    }

    public void desenhar(Graphics2D g) {
        for (Object obj : primitivas) {
            if (obj instanceof Reta) ((Reta)obj).desenhar(g);
            else if (obj instanceof Retangulo) ((Retangulo)obj).desenhar(g);
            else if (obj instanceof Triangulo) ((Triangulo)obj).desenhar(g);
            else if (obj instanceof Circulo) ((Circulo)obj).desenhar(g);
        }
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class GUI extends JPanel {
    private Figura figura;
    private String modo = "reta"; 
    private List<Ponto> pontosTemp;

    // Configurações de estilo
    private Color corAtual = Color.BLACK;
    private int espessuraAtual = 2;

    public GUI() {
        figura = new Figura();
        pontosTemp = new ArrayList<>();

        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                Ponto p = new Ponto(e.getX(), e.getY());
                pontosTemp.add(p);

                switch (modo) {
                    case "reta":
                        if (pontosTemp.size() == 2) {
                            figura.adicionar(new Reta(pontosTemp.get(0), pontosTemp.get(1), corAtual, espessuraAtual));
                            pontosTemp.clear();
                        }
                        break;
                    case "retangulo":
                        if (pontosTemp.size() == 2) {
                            figura.adicionar(new Retangulo(pontosTemp.get(0), pontosTemp.get(1), corAtual, espessuraAtual));
                            pontosTemp.clear();
                        }
                        break;
                    case "triangulo":
                        if (pontosTemp.size() == 3) {
                            figura.adicionar(new Triangulo(pontosTemp.get(0), pontosTemp.get(1), pontosTemp.get(2), corAtual, espessuraAtual));
                            pontosTemp.clear();
                        }
                        break;
                    case "circulo":
                        if (pontosTemp.size() == 2) {
                            int dx = pontosTemp.get(1).x - pontosTemp.get(0).x;
                            int dy = pontosTemp.get(1).y - pontosTemp.get(0).y;
                            int raio = (int)Math.sqrt(dx*dx + dy*dy);
                            figura.adicionar(new Circulo(pontosTemp.get(0), raio, corAtual, espessuraAtual));
                            pontosTemp.clear();
                        }
                        break;
                }
                repaint();
            }
        });
    }

    public void setModo(String modo) {
        this.modo = modo;
    }

    public void setCor(Color cor) {
        this.corAtual = cor;
    }

    public void setEspessura(int espessura) {
        this.espessuraAtual = espessura;
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        figura.desenhar((Graphics2D) g);
    }
}

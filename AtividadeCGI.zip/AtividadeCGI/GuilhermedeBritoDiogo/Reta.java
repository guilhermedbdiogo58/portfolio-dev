import java.awt.*;

public class Reta {
    private Ponto p1, p2;
    private Color cor;
    private int espessura;

    public Reta(Ponto p1, Ponto p2, Color cor, int espessura) {
        this.p1 = p1;
        this.p2 = p2;
        this.cor = cor;
        this.espessura = espessura;
    }

    public void desenhar(Graphics2D g) {
        g.setColor(cor);
        g.setStroke(new BasicStroke(espessura));
        g.drawLine(p1.x, p1.y, p2.x, p2.y);
    }
}

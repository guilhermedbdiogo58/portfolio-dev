import java.awt.*;

public class Circulo {
    private Ponto centro;
    private int raio;
    private Color cor;
    private int espessura;

    public Circulo(Ponto centro, int raio, Color cor, int espessura) {
        this.centro = centro;
        this.raio = raio;
        this.cor = cor;
        this.espessura = espessura;
    }

    public void desenhar(Graphics2D g) {
        g.setColor(cor);
        g.setStroke(new BasicStroke(espessura));
        g.drawOval(centro.x - raio, centro.y - raio, 2 * raio, 2 * raio);
    }
}

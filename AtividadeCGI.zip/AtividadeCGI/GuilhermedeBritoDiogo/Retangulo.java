import java.awt.*;

public class Retangulo {
    private Ponto p1, p2; // canto superior esquerdo e inferior direito
    private Color cor;
    private int espessura;

    public Retangulo(Ponto p1, Ponto p2, Color cor, int espessura) {
        this.p1 = p1;
        this.p2 = p2;
        this.cor = cor;
        this.espessura = espessura;
    }

    public void desenhar(Graphics2D g) {
        g.setColor(cor);
        g.setStroke(new BasicStroke(espessura));
        int x = Math.min(p1.x, p2.x);
        int y = Math.min(p1.y, p2.y);
        int w = Math.abs(p2.x - p1.x);
        int h = Math.abs(p2.y - p1.y);
        g.drawRect(x, y, w, h);
    }
}

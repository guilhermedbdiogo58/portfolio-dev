import java.awt.*;

public class Triangulo {
    private Ponto a, b, c;
    private Color cor;
    private int espessura;

    public Triangulo(Ponto a, Ponto b, Ponto c, Color cor, int espessura) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.cor = cor;
        this.espessura = espessura;
    }

    public void desenhar(Graphics2D g) {
        g.setColor(cor);
        g.setStroke(new BasicStroke(espessura));
        int[] xs = {a.x, b.x, c.x};
        int[] ys = {a.y, b.y, c.y};
        g.drawPolygon(xs, ys, 3);
    }
}

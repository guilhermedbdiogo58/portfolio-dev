import javax.swing.*;
import java.awt.*;

public class App {
    public static void main(String[] args) {
        JFrame janela = new JFrame("Mini App de Figuras");
        GUI gui = new GUI();

        // Painel lateral
        JPanel painelControles = new JPanel();
        painelControles.setLayout(new GridLayout(8, 1, 5, 5));
        painelControles.setBorder(BorderFactory.createTitledBorder("Configurações"));

        // Grupo de botões para selecionar figura
        ButtonGroup grupo = new ButtonGroup();

        JRadioButton botaoReta = new JRadioButton("Reta");
        botaoReta.addActionListener(e -> gui.setModo("reta"));
        grupo.add(botaoReta);
        painelControles.add(botaoReta);

        JRadioButton botaoRetangulo = new JRadioButton("Retângulo");
        botaoRetangulo.addActionListener(e -> gui.setModo("retangulo"));
        grupo.add(botaoRetangulo);
        painelControles.add(botaoRetangulo);

        JRadioButton botaoTriangulo = new JRadioButton("Triângulo");
        botaoTriangulo.addActionListener(e -> gui.setModo("triangulo"));
        grupo.add(botaoTriangulo);
        painelControles.add(botaoTriangulo);

        JRadioButton botaoCirculo = new JRadioButton("Círculo");
        botaoCirculo.addActionListener(e -> gui.setModo("circulo"));
        grupo.add(botaoCirculo);
        painelControles.add(botaoCirculo);

        // Cor
        painelControles.add(new JLabel("Cor:"));
        JComboBox<String> comboCor = new JComboBox<>(new String[]{"Preto", "Vermelho", "Verde", "Azul"});
        comboCor.addActionListener(e -> {
            String corEscolhida = (String) comboCor.getSelectedItem();
            switch (corEscolhida) {
                case "Vermelho": gui.setCor(Color.RED); break;
                case "Verde": gui.setCor(Color.GREEN); break;
                case "Azul": gui.setCor(Color.BLUE); break;
                default: gui.setCor(Color.BLACK); break;
            }
        });
        painelControles.add(comboCor);

        // Espessura
        painelControles.add(new JLabel("Espessura:"));
        JSpinner spinnerEspessura = new JSpinner(new SpinnerNumberModel(2, 1, 10, 1));
        spinnerEspessura.addChangeListener(e -> {
            gui.setEspessura((Integer) spinnerEspessura.getValue());
        });
        painelControles.add(spinnerEspessura);

        // Configuração da janela
        janela.setLayout(new BorderLayout());
        janela.add(painelControles, BorderLayout.WEST);
        janela.add(gui, BorderLayout.CENTER);

        janela.setSize(1000, 600);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setVisible(true);

        // Valores padrão
        botaoReta.setSelected(true);
        gui.setModo("reta");
        gui.setCor(Color.BLACK);
        gui.setEspessura(2);
    }
}
